package DBMS;

import java.io.Serializable;
import java.util.ArrayList;

public class Page implements Serializable {
	    private static int MAX_RECORDS; // Dynamic page size
	    private ArrayList<String[]> records;

	    public Page(int pageSize) {
	        MAX_RECORDS = pageSize;
	        this.records = new ArrayList<>();
	    }

	    public boolean isFull() {
	        return records.size() >= MAX_RECORDS;
	    }

	    public boolean addRecord(String[] record) {
	        if (!isFull()) {
	            records.add(record);
	            return true;
	        }
	        return false; // Page is full
	    }

	    public ArrayList<String[]> getRecords() {
	        return records;
	    }
	    public String[] getRecord(int recordIndex) {
	        if (recordIndex < 0 || recordIndex >= records.size()) {
	            System.out.println("Error: Record index out of bounds.");
	            return null;
	        }
	        return records.get(recordIndex);
	    }

	}