package DBMS;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import org.junit.Test;

public class DBApp
{
	static int dataPageSize = 2;
	private static HashMap<String, ArrayList<String>> traceLogs = new HashMap<>();
	
	public static void createTable(String tableName, String[] columnsNames)
	{
		try {
			   if (traceLogs.containsKey(tableName)) {
		            traceLogs.put(tableName, new ArrayList<>());
		        }
         Table newTable = new Table(tableName, columnsNames, dataPageSize);
         boolean tableStored = FileManager.storeTable(tableName, newTable);
         if (!tableStored) {
             System.out.println("Failed to store table: " + tableName);
         } else {
             //System.out.println("Table '" + tableName + "' created successfully.");
             String logEntry = "Table created name:" + tableName + ", columnsNames:" + Arrays.toString(columnsNames);
             addToTrace(tableName, logEntry);
         }
     } catch (Exception e) {
         System.err.println("Error creating table: " + e.getMessage());
     }
 }
	
	public static void insert(String tableName, String[] record)
	{
	    try {
	        long startTime = System.currentTimeMillis();
	        Table table = FileManager.loadTable(tableName);
	        if (table == null) {
	            System.out.println("Error: Table '" + tableName + "' does not exist.");
	            return;
	        }

	        boolean inserted = table.insertRecord(record);
	        if (!inserted) {
	            System.out.println("Error: Record insertion failed.");
	            return;
	        }

	        // Determine the page where the record was inserted
	        int pageNumber = table.getPages().size() - 1;
	        for (int i = 0; i < table.getPages().size(); i++) {
	            if (table.getPages().get(i).getRecords().contains(record)) {
	                pageNumber = i;
	                break;
	            }
	        }

	        // Store the updated page separately
	        Page updatedPage = table.getPages().get(pageNumber);
	        FileManager.storeTablePage(tableName, pageNumber, updatedPage);

	        // Also, store the updated table structure
	        FileManager.storeTable(tableName, table);

	        long executionTime = System.currentTimeMillis() - startTime;
	        //System.out.println("Record inserted successfully into '" + tableName + "'.");

	        String logEntry = "Inserted:" + Arrays.toString(record) + ", at page number:" + pageNumber + ", execution time (mil):" + executionTime;
	        addToTrace(tableName, logEntry);
	    } catch (Exception e) {
	        System.err.println("Error inserting record: " + e.getMessage());
	    }
	}
	
	public static ArrayList<String []> select(String tableName)
	{
		long startTime = System.currentTimeMillis();
        ArrayList<String[]> result = new ArrayList<>();

        Table table = FileManager.loadTable(tableName);
        int totalRecords = 0;
        int totalPages = table.getPages().size();
        
        for (Page page : table.getPages()) {
            result.addAll(page.getRecords());
            totalRecords += page.getRecords().size();
        }
        long executionTime = System.currentTimeMillis() - startTime;
        String logEntry = "Select all pages:" + totalPages + ", records:" + totalRecords + ", execution time (mil):" + executionTime;
        addToTrace(tableName, logEntry);

        return result;
        
	}   
	
	public static ArrayList<String []> select(String tableName, int pageNumber, int recordNumber)
	{
		long startTime = System.currentTimeMillis();
        ArrayList<String[]> result = new ArrayList<>();
        int x=0;

        
        try {
            Table table = FileManager.loadTable(tableName);
            if (table == null) {
            	System.out.println( "Error: Table '" + tableName + "' does not exist.");
            	;
            
              
            }
            
            else {

            if (pageNumber < 0 || pageNumber >= table.getPages().size()) {
            	System.out.println( "Error: Page number " + pageNumber + " out of bounds. Valid range: 0 - " + (table.getPages().size() - 1));
            
            
               
            }
            
            else {

            Page page = table.getPages().get(pageNumber);

            if (recordNumber < 0 || recordNumber >= page.getRecords().size()) {
            	System.out.println("Error: Record index " + recordNumber + " out of bounds. Valid range: 0 - " + (page.getRecords().size() - 1));
                  
               
            }
            else {
            	x=1;
            	String[] selectedRecord = page.getRecords().get(recordNumber);
                result.add(selectedRecord);
            
            	
            }
            
            }
            }

            
            long executionTime = System.currentTimeMillis() - startTime;
            String logEntry = "Select pointer page:" + pageNumber + ", record:" + recordNumber + ", total output count:" + x + ", execution time (mil):" + executionTime;
            addToTrace(tableName, logEntry);
            
            return result;
        } catch (Exception e) {
            System.err.println("Error selecting record: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
	
	public static ArrayList<String []> select(String tableName, String[] cols, String[] vals)
	{
		long startTime = System.currentTimeMillis();
        ArrayList<String[]> result = new ArrayList<>();
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            System.out.println("Error: Table '" + tableName + "' does not exist.");
            return result;
        }

        String[] columnNames = table.getColumnNames();
        int[] colIndices = new int[cols.length];
        for (int i = 0; i < cols.length; i++) {
            boolean found = false;
            for (int j = 0; j < columnNames.length; j++) {
                if (columnNames[j].equals(cols[i])) {
                    colIndices[i] = j;
                    found = true;
                    break;
                }
            }
            if (!found) {
                System.out.println("Error: Column '" + cols[i] + "' not found in table.");
                return result;
            }
        }

        ArrayList<String> pagesAndRecords = new ArrayList<>();
        int matchedRecords = 0;

        for (int pageIdx = 0; pageIdx < table.getPages().size(); pageIdx++) {
            Page page = table.getPages().get(pageIdx);
            int countInPage = 0;

            for (int recIdx = 0; recIdx < page.getRecords().size(); recIdx++) {
                String[] record = page.getRecords().get(recIdx);
                boolean matches = true;

                for (int i = 0; i < colIndices.length; i++) {
                    if (!record[colIndices[i]].equals(vals[i])) {
                        matches = false;
                        break;
                    }
                }

                if (matches) {
                    result.add(record);
                    countInPage++;
                    matchedRecords++;
                }
            }

            if (countInPage > 0) {
                pagesAndRecords.add("[" + pageIdx + ", " + countInPage + "]");
            }
        }


        long executionTime = System.currentTimeMillis() - startTime;
        String logEntry = "Select condition:" + Arrays.toString(cols) + "->" + Arrays.toString(vals) + ", Records per page:" + pagesAndRecords + ", records:" + matchedRecords + ", execution time (mil):" + executionTime;
        addToTrace(tableName, logEntry);

        return result;
    }
	
	public static String getFullTrace(String tableName) { 
		
	    ArrayList<String> logs = traceLogs.get(tableName);
	    if (logs == null || logs.isEmpty()) {
	        return "No operations recorded for table: " + tableName;
	    }

	    int totalPages = 0;
	    int totalRecords = 0;

	    //  Count pages by trying to load them using FileManager
	    while (true) {
	        Page page = FileManager.loadTablePage(tableName, totalPages);
	        if (page == null) {
	            break;  // Stop when a page cannot be loaded
	        }
	        totalRecords += page.getRecords().size();
	        totalPages++;
	    }

	    // Ensure correct format
	    return String.join("\n", logs) + "\nPages Count: " + totalPages + ", Records Count: " + totalRecords;
	}
	
	public static String getLastTrace(String tableName)
	{
		  ArrayList<String> logs = traceLogs.get(tableName);
	        if (logs == null || logs.isEmpty()) {
	            return "No recent operations recorded for table: " + tableName;
	        }
	        return logs.get(logs.size() - 1);
	    }
	
	private static void addToTrace(String tableName, String logEntry) {
        traceLogs.putIfAbsent(tableName, new ArrayList<>());
        traceLogs.get(tableName).add(logEntry);
    }
	
	public static void main(String []args) throws IOException 
	 { 
	   
	  String[] cols = {"id","name","major","semester","gpa"}; 
	  createTable("student", cols); 
	  String[] r1 = {"1", "stud1", "CS", "5", "0.9"}; 
	  insert("student", r1); 
	   
	  String[] r2 = {"2", "stud2", "BI", "7", "1.2"}; 
	  insert("student", r2); 
	   
	  String[] r3 = {"3", "stud3", "CS", "2", "2.4"}; 
	  insert("student", r3); 
	   
	  String[] r4 = {"4", "stud4", "DMET", "9", "1.2"}; 
	  insert("student", r4); 
	   
	  String[] r5 = {"5", "stud5", "BI", "4", "3.5"}; 
	  insert("student", r5); 
	  
	   
	   
	        System.out.println("Output of selecting the whole table content:"); 
	  ArrayList<String[]> result1 = select("student"); 
	        for (String[] array : result1) { 
	            for (String str : array) { 
	                System.out.print(str + " "); 
	            } 
	            System.out.println(); 
	        } 
	         
	        System.out.println("--------------------------------"); 
	        System.out.println("Output of selecting the output by position:"); 
	  ArrayList<String[]> result2 = select("student", 1, 1); 
	        for (String[] array : result2) { 
	            for (String str : array) { 
	                System.out.print(str + " "); 
	            } 
	            System.out.println();  
	        } 
	         
	        System.out.println("--------------------------------"); 
	        System.out.println("Output of selecting the output by column condition:"); 
	  ArrayList<String[]> result3 = select("student", new String[]{"gpa"}, new 
	String[]{"1.2"}); 
	        for (String[] array : result3) { 
	 
	 
	            for (String str : array) { 
	                System.out.print(str + " "); 
	            } 
	            System.out.println();  
	        } 
	        System.out.println("--------------------------------"); 
	  System.out.println("Full Trace of the table:"); 
	  System.out.println(getFullTrace("student")); 
	  System.out.println("--------------------------------"); 
	  System.out.println("Last Trace of the table:"); 
	  System.out.println(getLastTrace("student")); 
	  System.out.println("--------------------------------"); 
	  System.out.println("The trace of the Tables Folder:"); 
	  System.out.println(FileManager.trace()); 
	  FileManager.reset(); 
	  System.out.println("--------------------------------"); 
	  System.out.println("The trace of the Tables Folder after resetting:"); 
	  System.out.println(FileManager.trace()); 
	   
	   
	 } 
	
	
}
