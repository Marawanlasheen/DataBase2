package DBMS;

import java.io.Serializable;
import java.util.ArrayList;

public class Table implements Serializable {
	 private String tableName;
	    private String[] columnNames;
	    private ArrayList<Page> pages;
	    private int pageSize;

	    public Table(String tableName, String[] columnNames, int pageSize) {
	        this.tableName = tableName;
	        this.columnNames = columnNames;
	        this.pageSize = pageSize;
	        this.pages = new ArrayList<>(); // Do not create a page initially
	    }

	    public boolean insertRecord(String[] record) {
	        if (record.length != columnNames.length) {
	            System.out.println("Error: Record does not match column count.");
	            return false;
	        }

	        // Search for a non-full page
	        for (Page page : pages) {
	            if (!page.isFull()) {
	                page.addRecord(record);
	                return true;
	            }
	        }

	        // If no space, create a new page
	        Page newPage = new Page(pageSize);
	        newPage.addRecord(record);
	        pages.add(newPage);
	        return true;
	    }

	    public ArrayList<Page> getPages() {
	        return pages;
	    }

	    public String getTableName() {
	        return tableName;
	    }
	    public String[] selectRecord(int pageIndex, int recordIndex) {
	        if (pageIndex < 0 || pageIndex >= pages.size()) {
	            System.out.println("Error: Page index out of bounds.");
	            return null;
	        }

	        Page page = pages.get(pageIndex);
	        return page.getRecord(recordIndex);
	    }

	    public String[] getColumnNames() {
	        return columnNames;
	    }
	}
