package DBMS;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
// import java.util.Collections; // Not strictly needed for this change

public class Table implements Serializable
{
	private static final long serialVersionUID = 1L; // Recommended for Serializable classes
	private String name;
	private String[] columnsNames;
	private int pageCount;
	private int recordsCount;
	private ArrayList<String> trace;
	// private BitmapIndex bitmapIndex; // This field was commented out in your provided code, seems unused at Table level directly.

	
	public ArrayList<String> getTrace() {
		return trace;
	}


	public Table(String name, String[] columnsNames) 
	{
		super();
		this.name = name;
		this.columnsNames = columnsNames;
		this.trace = new ArrayList<String>();
		this.trace.add("Table created name:" + name + ", columnsNames:"
				+ Arrays.toString(columnsNames));
		this.pageCount = 0; // Initialize pageCount
		this.recordsCount = 0; // Initialize recordsCount
	}


	@Override
	public String toString() 
	{
		return "Table [name=" + name + ", columnsNames="
				+ Arrays.toString(columnsNames) + ", pageCount=" + pageCount
				+ ", recordsCount=" + recordsCount + "]";
	}
	
	
	public void insert(String[] record) {
	    long startTime = System.currentTimeMillis();

	    int targetPageIndex = -1;
        Page currentPage = null;

        if (pageCount > 0) {
            targetPageIndex = pageCount - 1; // Try last existing page
            currentPage = FileManager.loadTablePage(this.name, targetPageIndex);
        }

	    // If no pages exist, or last page is full/null, create a new one
	    if (currentPage == null || !currentPage.insert(record)) { // insert returns true if successful, false if full
	        currentPage = new Page(); // Create a new page
	        currentPage.insert(record); // Insert into the new page
	        targetPageIndex = pageCount; // New page will be at index 'pageCount'
	        pageCount++; // Increment page count
	    }
	   
	    FileManager.storeTablePage(this.name, targetPageIndex, currentPage);
	    recordsCount++; // Increment total records in the table

	    // Update bitmap indexes if they exist
	    for (int colIndex = 0; colIndex < columnsNames.length; colIndex++) {
	        String colName = columnsNames[colIndex];
	        BitmapIndex index = FileManager.loadTableIndex(this.name, colName);

	        if (index == null) continue; // No index for this column

	        String insertedValue = record[colIndex];

	        // Extend all existing bitmaps
	        for (String existingValInIndex : index.getIndex().keySet()) {
	            // index.add will append to the bitmap list for existingValInIndex
	            if (existingValInIndex.equals(insertedValue)) {
	                index.add(existingValInIndex, 1); // Append 1 for the current record
	            } else {
	                index.add(existingValInIndex, 0); // Append 0 for the current record
	            }
	        }

	        // If the insertedValue is new for this column's index
	        if (!index.getIndex().containsKey(insertedValue)) {   
	            ArrayList<Integer> newBitmap = new ArrayList<>();
	            // All (recordsCount - 1) previous records did not have this value
	            for (int i = 0; i < recordsCount - 1; i++) {
	                newBitmap.add(0);
	            }
	            newBitmap.add(1);  // Current new record has this value
	            index.putBitmap(insertedValue, newBitmap); // Add new value and its bitmap
	        }
	        
	        FileManager.storeTableIndex(this.name, colName, index); // Save the updated index
	    }

	    long stopTime = System.currentTimeMillis();
	    // Corrected trace message format:
	    this.trace.add("Inserted record: " + Arrays.toString(record) +
	        " in page number: " + targetPageIndex + "," + // Comma added here
	        " record number: " + (currentPage.getRecords().size() -1) + // Added record number for more detail, optional for regex
	        " execution time (mil):" + (stopTime - startTime));
	}

	// Helper method to convert query conditions (cols, vals) to a full-length condition array
	public String[] fixCond(String[] cols, String[] vals)
	{
		String[] res = new String[columnsNames.length]; // Nulls by default
		for(int i=0;i<columnsNames.length;i++) // For each column in the table
		{
			for(int j=0;j<cols.length;j++) // For each condition column
			{
				if(columnsNames[i].equals(cols[j])) // If table column matches condition column
				{
					res[i]=vals[j]; // Place the condition value at the correct index
					break; 
				}
			}
		}
		return res;
	}
		
	public ArrayList<String []> select(String[] cols, String[] vals)
	{
		String[] cond = fixCond(cols, vals); // Prepare full condition array
		String tracer ="Select condition:"+Arrays.toString(cols)+"->"+Arrays.toString(vals);
		ArrayList<ArrayList<Integer>> pagesResCount = new ArrayList<ArrayList<Integer>>();
		ArrayList<String []> res = new ArrayList<String []>();
		long startTime = System.currentTimeMillis();
		for(int i=0;i<pageCount;i++)
		{
			Page p = FileManager.loadTablePage(this.name, i);
			if (p == null) continue; // Skip if page doesn't load
			ArrayList<String []> pRes = p.select(cond); // Page-level select
			if(pRes.size()>0)
			{
				ArrayList<Integer> pr = new ArrayList<Integer>();
				pr.add(i); // Page number
				pr.add(pRes.size()); // Count of matching records in this page
				pagesResCount.add(pr);
				res.addAll(pRes);
			}
		}
		long stopTime = System.currentTimeMillis();
		tracer +=", Records per page:" + pagesResCount.toString() +", total matching records:"+res.size() // changed "records" to "total matching records" for clarity
				+", execution time (mil):"+(stopTime - startTime);
		this.trace.add(tracer);
		return res;
	}
	
	public ArrayList<String []> select(int pageNumber, int recordNumber)
	{
		String tracer ="Select pointer page:"+pageNumber+", record:"+recordNumber;
		ArrayList<String []> res = new ArrayList<String []>();
		long startTime = System.currentTimeMillis();
		Page p = FileManager.loadTablePage(this.name, pageNumber);
		if (p != null) {
			ArrayList<String []> pRes = p.select(recordNumber); // Page-level select by specific record index
			if(pRes.size()>0) // Should be 0 or 1 record
			{
				res.addAll(pRes);
			}
		} else {
		    tracer += ", Error: Page not found.";
        }
		long stopTime = System.currentTimeMillis();
		tracer+=", total output count:"+res.size()
				+", execution time (mil):"+(stopTime - startTime);
		this.trace.add(tracer);
		return res;
	}
	
	
	public ArrayList<String []> select()
	{
		ArrayList<String []> res = new ArrayList<String []>();
		long startTime = System.currentTimeMillis();
		for(int i=0;i<pageCount;i++)
		{
			Page p = FileManager.loadTablePage(this.name, i);
			if (p == null) continue; // Skip if page doesn't load
			res.addAll(p.select()); // Select all records from this page
		}
		long stopTime = System.currentTimeMillis();
		this.trace.add("Select all. Pages iterated:" + pageCount+", total records retrieved:"+res.size() // "recordsCount" is total in table, "res.size()" is what's retrieved
				+", execution time (mil):"+(stopTime - startTime));
		return res;
	}
	
	public int getPageCount() {
		return pageCount;
	}

	public int getRecordsCount() {
		return recordsCount;
	}

	public String[] getColumnsNames() {
		return columnsNames;
	}

	public String getTableName() { // Added getter for table name
		return name;
	}

	public String getFullTrace() 
	{
		StringBuilder resBuilder = new StringBuilder();
		for(int i=0;i<this.trace.size();i++)
		{
			resBuilder.append(this.trace.get(i)).append("\n");
		}
		resBuilder.append("Pages Count: ").append(pageCount)
		          .append(", Records Count: ").append(recordsCount)
		          .append(", Indexed Columns: ").append(this.indexedcol().toString()); // Use toString for ArrayList
		return resBuilder.toString();
	}
	
	public String getLastTrace() 
	{
	    if (this.trace == null || this.trace.isEmpty()) {
	        return "No trace available for table " + this.name;
	    }
		return this.trace.get(this.trace.size()-1);
	}

	public ArrayList<String> indexedcol (){
		ArrayList<String> colnamesthathaveindex = new  ArrayList<>();
		if (columnsNames == null) return colnamesthathaveindex; // Guard against null columnsNames

		for (int i =0; i<columnsNames.length;i++){		
			String columnName= columnsNames[i];
			// Assuming FileManager.loadTableIndex returns null if index doesn't exist
			BitmapIndex indexavailable = FileManager.loadTableIndex(name, columnName); 
			if (indexavailable!=null){
				colnamesthathaveindex.add(columnName);
			}
	    }
		return colnamesthathaveindex;
	}
}