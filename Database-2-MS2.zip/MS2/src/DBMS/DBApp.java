package DBMS;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DBApp
{
	static int dataPageSize = 2;


	public static void createTable(String tableName, String[] columnsNames)
	{
		Table t = new Table(tableName, columnsNames);
		FileManager.storeTable(tableName, t);
	}

	public static void insert(String tableName, String[] record)
	{
		Table t = FileManager.loadTable(tableName);
		t.insert(record);
		FileManager.storeTable(tableName, t);
	}

	public static ArrayList<String []> select(String tableName)
	{
		Table t = FileManager.loadTable(tableName);
		ArrayList<String []> res = t.select();
		FileManager.storeTable(tableName, t);
		return res;
	}

	public static ArrayList<String []> select(String tableName, int pageNumber, int recordNumber)
	{
		Table t = FileManager.loadTable(tableName);
		ArrayList<String []> res = t.select(pageNumber, recordNumber);
		FileManager.storeTable(tableName, t);
		return res;
	}

	public static ArrayList<String []> select(String tableName, String[] cols, String[] vals)
	{
		Table t = FileManager.loadTable(tableName);
		ArrayList<String []> res = t.select(cols, vals);
		FileManager.storeTable(tableName, t);
		return res;
	}

	public static String getFullTrace(String tableName)
	{
		Table t = FileManager.loadTable(tableName);
		String res = t.getFullTrace();
		return res;
	}

	public static String getLastTrace(String tableName)
	{
		Table t = FileManager.loadTable(tableName);
		String res = t.getLastTrace();
		return res;
	}
	
	public static ArrayList<String []> validateRecords( String tableName){
		Table t = FileManager.loadTable(tableName);
		if (t == null) {
			// System.out.println("Table not found during validation: " + tableName); // Per problem, stderr/stdout minimal
			return new ArrayList<>();
		}

		String fullTraceLog = t.getFullTrace(); 
		ArrayList<String[]> recordsPotentiallyMissing = new ArrayList<>();
		ArrayList<String> allInsertionLogs = new ArrayList<>();

		Pattern insertionPattern = Pattern.compile("Inserted record: \\[(.*?)\\] in page number: (\\d+),");

		for (String logEntry : fullTraceLog.split("\n")) {
			if (logEntry.contains("Inserted record:")) { 
				allInsertionLogs.add(logEntry);
			}
		}

		ArrayList<Integer> actualStoredPageIds = getPagesFromTrace(tableName);

		for (String insertionLog : allInsertionLogs) {
			Matcher matcher = insertionPattern.matcher(insertionLog);
			if (matcher.find()) {
				String recordContentString = matcher.group(1); 
				String pageNumString = matcher.group(2);       

				try {
					int loggedPageNum = Integer.parseInt(pageNumString.trim());
					if (!actualStoredPageIds.contains(loggedPageNum)) {
						String[] recordValues = recordContentString.split(",\\s*");
						recordsPotentiallyMissing.add(recordValues);
					}
				} catch (NumberFormatException e) {
					// System.err.println("Could not parse page number from log entry: " + insertionLog);
				}
			}
		}
		
		String validationLogMessage = "Validating records. " + recordsPotentiallyMissing.size() + " records missing.";
		if (recordsPotentiallyMissing.size() > 0) {
		    validationLogMessage += " (These were identified based on discrepancies between insertion logs and actual stored pages).";
		}
		t.getTrace().add(validationLogMessage);
		FileManager.storeTable(tableName, t);

		return recordsPotentiallyMissing;
	}
	
	
	public static ArrayList<Integer> getPagesFromTrace(String tableName) {
	    ArrayList<Integer> foundPageNumbers = new ArrayList<>();
	    File tableDirectory = new File(FileManager.directory.getAbsolutePath() + File.separator + tableName);

	    if (!tableDirectory.exists() || !tableDirectory.isDirectory()) {
	        return foundPageNumbers; 
	    }

	    File[] pageFiles = tableDirectory.listFiles(); 

	    if (pageFiles == null) {
	        return foundPageNumbers; 
	    }

	    for (File file : pageFiles) {
	        if (file.isFile() && file.getName().endsWith(".db")) {
	            String fileNameWithoutExtension = file.getName().substring(0, file.getName().lastIndexOf(".db"));
	            try {
	                int pageNumber = Integer.parseInt(fileNameWithoutExtension);
	                foundPageNumbers.add(pageNumber);
	            } catch (NumberFormatException e) {
	                 // System.err.println("Skipping non-numeric page file: " + file.getName());
	            }
	        }
	    }
	    Collections.sort(foundPageNumbers); 
	    return foundPageNumbers;
	}

	
	public static void recoverRecords(String tableName, ArrayList<String[]> missing) {
	    Table t = FileManager.loadTable(tableName);
	    if (t == null) {
	        // System.err.println("Table " + tableName + " not found for recovery.");
	        return;
	    }

	    ArrayList<Integer> existingPageIds = getPagesFromTrace(tableName);
	    ArrayList<Integer> newlyCreatedPageIds = new ArrayList<>();
        int maxLoggedPageId = -1;
        if (t.getTrace() != null && !t.getTrace().isEmpty()) {
            Pattern insertionPattern = Pattern.compile("Inserted record: .*? in page number: (\\d+),");
            for (String logEntry : t.getFullTrace().split("\n")) { 
                Matcher matcher = insertionPattern.matcher(logEntry);
                if (matcher.find()) {
                    try {
                        maxLoggedPageId = Math.max(maxLoggedPageId, Integer.parseInt(matcher.group(1).trim()));
                    } catch (NumberFormatException e) { /* ignore */ }
                }
            }
        }
        int totalPotentialPages = Math.max(t.getPageCount(), maxLoggedPageId + 1) ;
	    
	    int numberOfRecordsRecovered = 0;
	    int currentMissingRecordIdx = 0; 

	    for (int pageIdx = 0; pageIdx < totalPotentialPages && currentMissingRecordIdx < missing.size(); pageIdx++) {
	        if (!existingPageIds.contains(pageIdx)) { 
	            Page newPageToCreate = new Page(); 
	            int recordsAddedToThisPage = 0;
	            
	            while (recordsAddedToThisPage < dataPageSize && currentMissingRecordIdx < missing.size()) {
	                String[] recordToInsert = missing.get(currentMissingRecordIdx);
	                newPageToCreate.insert(recordToInsert); 
	                
	                numberOfRecordsRecovered++;
	                recordsAddedToThisPage++;
	                currentMissingRecordIdx++; 
	            }
	            
	            if (recordsAddedToThisPage > 0) { 
	                FileManager.storeTablePage(tableName, pageIdx, newPageToCreate); 
	                newlyCreatedPageIds.add(pageIdx); 
	            }
	        }
	    }
	    
	    t.getTrace().add("Recovering records: Attempted to place " + missing.size() + " records. " 
	                     + numberOfRecordsRecovered + " records placed in pages: " + newlyCreatedPageIds.toString() + ".");
	    FileManager.storeTable(tableName, t);
	}
	
	
	public static void createBitMapIndex(String tableName, String colName) {
		long executionStartTime = System.currentTimeMillis();
		Table t = FileManager.loadTable(tableName);
		if (t == null) {
			// System.err.println("Table " + tableName + " not found for bitmap index creation.");
			return;
		}

		String[] tableColumns = t.getColumnsNames();
		int targetColumnIndex = -1;
		for (int i = 0; i < tableColumns.length; i++) {
			if (tableColumns[i].equals(colName)) {
				targetColumnIndex = i;
				break;
			}
		}

		if (targetColumnIndex == -1) {
			// System.err.println("Column '" + colName + "' not found in table '" + tableName + "'. Index not created.");
			return;
		}

		ArrayList<String[]> allTableRecords = getallrecords(tableName);
		Set<String> distinctValuesInColumn = new HashSet<>();
		
        for (String[] record : allTableRecords) {
            if (record.length > targetColumnIndex && record[targetColumnIndex] != null) {
                distinctValuesInColumn.add(record[targetColumnIndex]);
            }
        }

		ArrayList<String> sortedUniqueValues = new ArrayList<>(distinctValuesInColumn);
		Collections.sort(sortedUniqueValues); 

		BitmapIndex newBitmapIndex = new BitmapIndex();

     for (String uniqueVal : sortedUniqueValues) {
         ArrayList<Integer> bitmap = new ArrayList<>(Collections.nCopies(allTableRecords.size(), 0));
         newBitmapIndex.getIndex().put(uniqueVal, bitmap);
     }

     for (int recordIdx = 0; recordIdx < allTableRecords.size(); recordIdx++) {
         String[] record = allTableRecords.get(recordIdx);
         String actualValueInRecord = (record.length > targetColumnIndex && record[targetColumnIndex] != null) ? record[targetColumnIndex] : null;
         
         if (actualValueInRecord != null) {
             ArrayList<Integer> bitmapForValue = newBitmapIndex.getIndex().get(actualValueInRecord);
             if (bitmapForValue != null) { 
                 bitmapForValue.set(recordIdx, 1);
             }
         }
     }

		FileManager.storeTableIndex(tableName, colName, newBitmapIndex);
		long executionEndTime = System.currentTimeMillis();
		t.getTrace().add("Index created for column: " + colName + ", execution time (mil):" + (executionEndTime - executionStartTime)); 
		FileManager.storeTable(tableName, t);
	}
	
	
	public static String getValueBits(String tableName, String colName, String value) {
	    BitmapIndex columnIndex = FileManager.loadTableIndex(tableName, colName);

	    if (columnIndex == null || columnIndex.getIndex() == null) {
            Table t = FileManager.loadTable(tableName);
            int recordCount = 0;
            if (t != null) { 
                 recordCount = getallrecords(tableName).size();
            }
            StringBuilder zeroBitmap = new StringBuilder(recordCount);
            for(int i = 0; i < recordCount; i++) zeroBitmap.append('0');
            return zeroBitmap.toString();
	    }

	    ArrayList<Integer> bitList = columnIndex.getIndex().get(value);

	    if (bitList == null) { 
	        int bitmapLength = 0;
	        if (!columnIndex.getIndex().isEmpty()) {
	            ArrayList<Integer> anyEntryBitList = columnIndex.getIndex().values().iterator().next();
	            if (anyEntryBitList != null) {
	                bitmapLength = anyEntryBitList.size();
	            }
	        } else {
                Table table = FileManager.loadTable(tableName);
                if (table != null) {
                    bitmapLength = getallrecords(tableName).size();
                }
            }
	        StringBuilder zeroBitmap = new StringBuilder(bitmapLength);
	        for (int i = 0; i < bitmapLength; i++) {
	            zeroBitmap.append('0');
	        }
	        return zeroBitmap.toString();
	    }

	    StringBuilder bitStreamBuilder = new StringBuilder(bitList.size());
	    for (Integer bit : bitList) {
	        bitStreamBuilder.append(bit);
	    }
	    return bitStreamBuilder.toString();
	}
	

	public static ArrayList<String []> selectIndex(String tableName,String[] cols, String[] vals){
		if (cols.length != vals.length){
			return new ArrayList<>(); 
		}
		
		Table t = FileManager.loadTable(tableName);
		if (t == null) {
		    return new ArrayList<>();
		}

		ArrayList<String[]> allRecordsInTable = getallrecords(tableName); 
		ArrayList<String[]> resultSet = new ArrayList<>();
		  
		List<String> indexedQueryCols = new ArrayList<>();
		List<String> nonIndexedQueryColsInternal = new ArrayList<>(); 
		  
		for (String colName : cols){ 
		    BitmapIndex index = FileManager.loadTableIndex(tableName, colName); 
		    if (index != null && index.getIndex() != null && !index.getIndex().isEmpty()){ 
		        indexedQueryCols.add(colName);
		    } else {
		        nonIndexedQueryColsInternal.add(colName);
		    }
	    }
		
		long startTime = System.currentTimeMillis();
		ArrayList<String[]> intermediateResults = new ArrayList<>(); 
        int[] finalCombinedBitmap = null;

		if (!indexedQueryCols.isEmpty()) {
		    List<String> bitmapsForIndexedCols = new ArrayList<>();
		    for (String indexedCol : indexedQueryCols) {
		        String valueForCol = ""; 
		        for(int i=0; i < cols.length; i++){
		            if(cols[i].equals(indexedCol)){
		                valueForCol = vals[i];
		                break;
		            }
		        }
		        bitmapsForIndexedCols.add(getValueBits(tableName, indexedCol, valueForCol));
		    }
         
             if (!bitmapsForIndexedCols.isEmpty()) {
                 String firstBitmapStr = bitmapsForIndexedCols.get(0);
                 // Ensure firstBitmapStr corresponds to the actual number of records if it's all zeros
                 if (firstBitmapStr.isEmpty() && allRecordsInTable.size() > 0) { 
                    StringBuilder sb = new StringBuilder(allRecordsInTable.size());
                    for(int k=0; k<allRecordsInTable.size(); k++) sb.append('0');
                    firstBitmapStr = sb.toString();
                 }


                 if (!firstBitmapStr.isEmpty()) { // Must have a valid (even if all zeros) first bitmap
                     finalCombinedBitmap = bitmapToIntArray(firstBitmapStr);

                     for (int i = 1; i < bitmapsForIndexedCols.size(); i++) {
                         String currentBitmapStr = bitmapsForIndexedCols.get(i);
                         if (currentBitmapStr.isEmpty() && allRecordsInTable.size() > 0) {
                            StringBuilder sb = new StringBuilder(allRecordsInTable.size());
                            for(int k=0; k<allRecordsInTable.size(); k++) sb.append('0');
                            currentBitmapStr = sb.toString();
                         }

                         if (currentBitmapStr.isEmpty() && finalCombinedBitmap.length > 0) { // Current is empty, effectively all zeros
                            for(int k=0; k < finalCombinedBitmap.length; k++) finalCombinedBitmap[k] = 0;
                            break; 
                         }
                         if (currentBitmapStr.isEmpty()) continue; // Skip if truly empty and no base length

                         int[] currentBitmapArray = bitmapToIntArray(currentBitmapStr);
                         finalCombinedBitmap = bitwiseAnd(finalCombinedBitmap, currentBitmapArray);
                         if (isAllZeros(finalCombinedBitmap) && finalCombinedBitmap.length > 0) break; 
                     }
                 } else { 
                      finalCombinedBitmap = new int[allRecordsInTable.size()]; // All zeros if first bitmap was empty
                 }
             }


		    if (finalCombinedBitmap != null && finalCombinedBitmap.length > 0) {
		        for (int i = 0; i < finalCombinedBitmap.length && i < allRecordsInTable.size(); i++){ 
		            if (finalCombinedBitmap[i] == 1){
		                intermediateResults.add(allRecordsInTable.get(i));
		            }
		        }
		    }

		    if (!nonIndexedQueryColsInternal.isEmpty()) { 
		        resultSet = filterRecordsByNonIndexedConditions(t, intermediateResults, nonIndexedQueryColsInternal, cols, vals);
		    } else { 
		        resultSet.addAll(intermediateResults); 
		    }

		} else { 
		    intermediateResults.addAll(allRecordsInTable); 
            resultSet = filterRecordsByNonIndexedConditions(t, intermediateResults, nonIndexedQueryColsInternal, cols, vals);
		}
		
		long stopTime = System.currentTimeMillis();
		long executionTime = stopTime - startTime;
		
		Collections.sort(indexedQueryCols); 
        List<String> sortedNonIndexedQueryColsForTrace = new ArrayList<>(nonIndexedQueryColsInternal);
        Collections.sort(sortedNonIndexedQueryColsForTrace);
		
		String traceMessage;
        int indexedSelectionIntermediateCount = 0;
        if (!indexedQueryCols.isEmpty() && finalCombinedBitmap != null) {
            for (int bit : finalCombinedBitmap) {
                if (bit == 1) indexedSelectionIntermediateCount++;
            }
        }

		boolean queryHasIndexed = !indexedQueryCols.isEmpty();
		boolean queryHasNonIndexed = !nonIndexedQueryColsInternal.isEmpty();

		if (queryHasIndexed && queryHasNonIndexed) { 
			traceMessage = String.format("Select index condition:%s->%s, Indexed columns: %s, Indexed selection count: %d, Non Indexed: %s, Final count: %d, execution time (mil):%d",
					Arrays.toString(cols), Arrays.toString(vals), indexedQueryCols.toString(),
					indexedSelectionIntermediateCount, sortedNonIndexedQueryColsForTrace.toString(), resultSet.size(), executionTime);
		} else if (queryHasIndexed) { 
			traceMessage = String.format("Select index condition:%s->%s, Indexed columns: %s, Indexed selection count: %d, Final count: %d, execution time (mil):%d",
					Arrays.toString(cols), Arrays.toString(vals), indexedQueryCols.toString(),
					resultSet.size(), resultSet.size(), executionTime);
		} else if (queryHasNonIndexed) { 
			traceMessage = String.format("Select index condition:%s->%s, Non Indexed: %s, Final count: %d, execution time (mil):%d",
					Arrays.toString(cols), Arrays.toString(vals), sortedNonIndexedQueryColsForTrace.toString(),
					resultSet.size(), executionTime);
		} else { 
			traceMessage = String.format("Select index condition:%s->%s, No query columns specified, Final count: %d, execution time (mil):%d",
					Arrays.toString(cols), Arrays.toString(vals), resultSet.size(), executionTime);
		}
		t.getTrace().add(traceMessage);
		FileManager.storeTable(tableName, t);
		return resultSet;
	}
	
	
	private static ArrayList<String[]> filterRecordsByNonIndexedConditions(
	        Table table,
	        ArrayList<String[]> recordsToFilter,
	        List<String> nonIndexedConditionCols, 
	        String[] originalQueryCols,           
	        String[] originalQueryVals) {         

	    ArrayList<String[]> finalFilteredResults = new ArrayList<>();
     if (recordsToFilter.isEmpty() && !nonIndexedConditionCols.isEmpty()) {
         return finalFilteredResults;
     }
     if (nonIndexedConditionCols.isEmpty()) { 
         finalFilteredResults.addAll(recordsToFilter);
         return finalFilteredResults;
     }

	    String[] tableSchema = table.getColumnsNames();
	    Map<String, Integer> tableColNameToIndexMap = new HashMap<>();
	    for (int i = 0; i < tableSchema.length; i++) {
	        tableColNameToIndexMap.put(tableSchema[i], i);
	    }

     Map<String, String> nonIndexedConditionsQueryMap = new HashMap<>();
     for(int i = 0; i < originalQueryCols.length; i++) {
         if (nonIndexedConditionCols.contains(originalQueryCols[i])) {
            nonIndexedConditionsQueryMap.put(originalQueryCols[i], originalQueryVals[i]);
         }
     }

	    for (String[] record : recordsToFilter) {
	        boolean matchesAllNonIndexed = true;
	        for (Map.Entry<String, String> conditionEntry : nonIndexedConditionsQueryMap.entrySet()) {
	            String nonIndexedColName = conditionEntry.getKey();
	            String expectedValue = conditionEntry.getValue();
	            
	            Integer recordColIdx = tableColNameToIndexMap.get(nonIndexedColName);

	            if (recordColIdx == null) { 
	                matchesAllNonIndexed = false; 
	                break; 
	            }
	            
	            if (record.length <= recordColIdx || record[recordColIdx] == null || !record[recordColIdx].equals(expectedValue)) {
	                matchesAllNonIndexed = false;
	                break;
	            }
	        }
	        if (matchesAllNonIndexed) {
	            finalFilteredResults.add(record);
	        }
	    }
	    return finalFilteredResults;
	}
	
	
	private static ArrayList<String []> getallrecords (String tablename){
		Table t = FileManager.loadTable(tablename);
		if (t == null) {
		    return new ArrayList<>(); 
		}

		ArrayList<String []> allRecordsList = new ArrayList<>();
		int pageCount = t.getPageCount(); 
		for(int i = 0; i < pageCount; i++){
			Page currentPage = FileManager.loadTablePage(tablename, i); 
			if (currentPage != null) {
			    ArrayList<String []> recordsInPage = currentPage.getRecords();
			    if (recordsInPage != null) {
			        allRecordsList.addAll(recordsInPage);
			    }
			}
		}
		return allRecordsList;
	}
	
    private static boolean isAllZeros(int[] bitmap) {
        if (bitmap == null) return true; 
        for (int bit : bitmap) {
            if (bit == 1) return false;
        }
        return true;
    }
	
	private static int[] bitmapToIntArray(String bitmapString) {
	    if (bitmapString == null || bitmapString.isEmpty()) {
         return new int[0];
     }
	    int[] resultArray = new int[bitmapString.length()];
	    char[] chars = bitmapString.toCharArray();
	    for (int i = 0; i < chars.length; i++) {
	        resultArray[i] = (chars[i] == '1' ? 1 : 0);
	    }
	    return resultArray;
	}
	
	
	public static int[] bitwiseAnd(int[] bitmapArray1, int[] bitmapArray2) {
	    if (bitmapArray1 == null && bitmapArray2 == null) return new int[0];
        if (bitmapArray1 == null || bitmapArray1.length == 0) {
            if(bitmapArray2 != null) return new int[bitmapArray2.length]; // all zeros of other's length
            return new int[0];
        }
        if (bitmapArray2 == null || bitmapArray2.length == 0) {
             return new int[bitmapArray1.length]; // all zeros of other's length
        }
        
	    if (bitmapArray1.length != bitmapArray2.length) {
	        // System.err.println("Error: Bitmaps for AND operation have different lengths... ");
	        // To handle potential issues with getValueBits returning variable length empty strings
            // We should ideally ensure they are padded to full record length before ANDing.
            // For now, if lengths mismatch, it's an error state for AND.
	        return new int[Math.max(bitmapArray1.length, bitmapArray2.length)]; // return all zeros of the longer one
	    }

	    int[] resultBitmap = new int[bitmapArray1.length];
	    for (int i = 0; i < bitmapArray1.length; i++) {
	        resultBitmap[i] = bitmapArray1[i] & bitmapArray2[i];  
	    }
	    return resultBitmap;
	}
	
	public static void main(String []args) throws IOException 
	{ 
	FileManager.reset(); 
	String[] cols = {"id","name","major","semester","gpa"}; 
	createTable("student", cols); 
	String[] r1 = {"1", "stud1", "CS", "5", "0.9"}; 
	insert("student", r1); 
	   
	String[] r2 = {"2", "stud2", "BI", "7", "1.2"}; 
	insert("student", r2); 
	   
	String[] r3 = {"3", "stud3", "CS", "2", "2.4"}; 
	insert("student", r3); 
	   
	createBitMapIndex("student", "gpa"); 
	createBitMapIndex("student", "major"); 
	   
	System.out.println("Bitmap of the value of CS from the major index: "+getValueBits("student", "major", "CS")); 
	System.out.println("Bitmap of the value of 1.2 from the gpa index: "+getValueBits("student", "gpa", "1.2")); 
	System.out.println("Bitmap of the value of DMA from the major index: "+getValueBits("student", "major", "DMA")); 
	   
	String[] r4 = {"4", "stud4", "CS", "9", "1.2"}; 
	insert("student", r4); 
	   
	String[] r5 = {"5", "stud5", "BI", "4", "3.5"}; 
	insert("student", r5); 
	   
	System.out.println("After new insertions:");  
	System.out.println("Bitmap of the value of CS from the major index: "+getValueBits("student", "major", "CS")); 
	System.out.println("Bitmap of the value of 1.2 from the gpa index: "+getValueBits("student", "gpa", "1.2")); 
	     
	   
	System.out.println("\nOutput of selection using index when all columns of the select conditions are indexed:"); 
	ArrayList<String[]> result1 = selectIndex("student", new String[] {"major","gpa"}, new String[] {"CS","1.2"}); 
	for (String[] array : result1) { 
        for(int i=0; i<array.length; i++) System.out.print(array[i] + (i==array.length-1?"":" "));
        System.out.println();
    }  
	System.out.println("Last trace of the table: "+getLastTrace("student")); 
	System.out.println("--------------------------------"); 
	         
	System.out.println("\nOutput of selection using index when only one column of the select conditions is indexed:"); 
	ArrayList<String[]> result2 = selectIndex("student", new String[] {"major","semester"}, new String[] {"CS","5"}); 
	for (String[] array : result2) { 
        for(int i=0; i<array.length; i++) System.out.print(array[i] + (i==array.length-1?"":" "));
        System.out.println();
    }
	System.out.println("Last trace of the table: "+getLastTrace("student")); 
	System.out.println("--------------------------------"); 
	         
	System.out.println("\nOutput of selection using index when some of the columns of the select conditions are indexed:"); 
	ArrayList<String[]> result3 = selectIndex("student", new String[] {"major","semester","gpa" }, new String[] {"CS","5", "0.9"}); 
	for (String[] array : result3) { 
        for(int i=0; i<array.length; i++) System.out.print(array[i] + (i==array.length-1?"":" "));
        System.out.println();
    }
	System.out.println("Last trace of the table: "+getLastTrace("student")); 
	System.out.println("--------------------------------"); 

    System.out.println("\nOutput of selection using index with a non-indexed column only:");
    ArrayList<String[]> result4 = selectIndex("student", new String[]{"semester"}, new String[]{"9"});
    for (String[] array : result4) { 
        for(int i=0; i<array.length; i++) System.out.print(array[i] + (i==array.length-1?"":" "));
        System.out.println();
    }
    System.out.println("Last trace of the table: " + getLastTrace("student"));
    System.out.println("--------------------------------");

    System.out.println("\nOutput of selection using index with an indexed column having no matches:");
    ArrayList<String[]> result5 = selectIndex("student", new String[]{"major"}, new String[]{"Eng"}); 
    for (String[] array : result5) { 
        for(int i=0; i<array.length; i++) System.out.print(array[i] + (i==array.length-1?"":" "));
        System.out.println();
    }
    System.out.println("Last trace of the table: " + getLastTrace("student"));
    System.out.println("--------------------------------");

    System.out.println("\nValidating student table (should be 0 missing initially if all pages are there):");
    ArrayList<String[]> missing = validateRecords("student");
    System.out.println("Missing records found: " + missing.size());
    for(String[] rec : missing) System.out.println(Arrays.toString(rec));
    System.out.println("Last trace of student table: " + getLastTrace("student"));
    System.out.println("--------------------------------");

	System.out.println("\nFull Trace of the student table:"); 
	System.out.println(getFullTrace("student")); 
	System.out.println("--------------------------------"); 
	System.out.println("\nThe trace of the Tables Folder:"); 
	System.out.println(FileManager.trace()); 
	}
	   
}